package com.espinosa.biomedicalservice.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.espinosa.biomedicalservice.data.ClienteDao
import kotlinx.coroutines.launch

@Composable fun ClientesScreen(dao:ClienteDao,nav:NavController){
    val lista by dao.observarActivos().collectAsState(emptyList())
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            Text("Clientes",style=MaterialTheme.typography.headlineSmall)
            Button({nav.navigate("nuevo_cliente")}){Text("＋")}
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(lista){c->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
                Text(c.nombre,style=MaterialTheme.typography.titleMedium)
                if(c.contacto.isNotBlank())Text("Contacto: ${c.contacto}")
                if(c.telefono.isNotBlank())Text("Teléfono: ${c.telefono}")
                if(c.whatsapp.isNotBlank())Text("WhatsApp: ${c.whatsapp}")
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton({}){Text("Editar")}
                    OutlinedButton({scope.launch{dao.archivar(c.id)}}){Text("🗑️ Archivar")}
                }
            }}}
        }
    }
}
