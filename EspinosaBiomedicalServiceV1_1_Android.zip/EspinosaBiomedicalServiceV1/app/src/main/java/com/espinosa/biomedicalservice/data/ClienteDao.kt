package com.espinosa.biomedicalservice.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClienteDao {
    @Query("SELECT * FROM clientes WHERE archivado = 0 ORDER BY nombre")
    fun observarActivos(): Flow<List<Cliente>>
    @Query("SELECT * FROM clientes WHERE archivado = 0 AND (nombre LIKE '%' || :q || '%' OR rut LIKE '%' || :q || '%' OR telefono LIKE '%' || :q || '%' OR whatsapp LIKE '%' || :q || '%' OR email LIKE '%' || :q || '%') ORDER BY nombre")
    fun buscar(q: String): Flow<List<Cliente>>
    @Insert suspend fun insertar(cliente: Cliente): Long
    @Update suspend fun actualizar(cliente: Cliente)
    @Query("UPDATE clientes SET archivado=1 WHERE id=:id") suspend fun archivar(id: Long)
    @Query("UPDATE clientes SET archivado=0 WHERE id=:id") suspend fun restaurar(id: Long)
    @Query("DELETE FROM clientes WHERE id=:id") suspend fun eliminarDefinitivamente(id: Long)
    @Query("SELECT * FROM clientes WHERE archivado=1 ORDER BY nombre") fun observarPapelera(): Flow<List<Cliente>>
}
