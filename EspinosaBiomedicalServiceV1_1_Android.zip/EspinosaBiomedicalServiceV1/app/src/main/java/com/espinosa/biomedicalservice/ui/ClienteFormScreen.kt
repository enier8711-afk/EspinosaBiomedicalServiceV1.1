package com.espinosa.biomedicalservice.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.espinosa.biomedicalservice.data.Cliente
import com.espinosa.biomedicalservice.data.ClienteDao
import kotlinx.coroutines.launch

@Composable fun ClienteFormScreen(dao:ClienteDao,nav:NavController){
    val scope=rememberCoroutineScope()
    var nombre by remember{mutableStateOf("")}; var rut by remember{mutableStateOf("")}
    var contacto by remember{mutableStateOf("")}; var telefono by remember{mutableStateOf("")}
    var whatsapp by remember{mutableStateOf("")}; var email by remember{mutableStateOf("")}
    var direccion by remember{mutableStateOf("")}; var ciudad by remember{mutableStateOf("")}
    var departamento by remember{mutableStateOf("")}; var observaciones by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Nuevo cliente",style=MaterialTheme.typography.headlineSmall)
        Field("Nombre / Razón social",nombre){nombre=it}; Field("RUT",rut){rut=it}
        Field("Contacto",contacto){contacto=it}; Field("Teléfono",telefono){telefono=it}
        Field("WhatsApp",whatsapp){whatsapp=it}; Field("Correo",email){email=it}
        Field("Dirección",direccion){direccion=it}; Field("Ciudad",ciudad){ciudad=it}
        Field("Departamento",departamento){departamento=it}; Field("Observaciones",observaciones){observaciones=it}
        Button(enabled=nombre.isNotBlank(),onClick={scope.launch{
            dao.insertar(Cliente(nombre=nombre,rut=rut,contacto=contacto,telefono=telefono,whatsapp=whatsapp,email=email,direccion=direccion,ciudad=ciudad,departamento=departamento,observaciones=observaciones))
            nav.popBackStack()
        }},Modifier.fillMaxWidth()){Text("Guardar cliente")}
        OutlinedButton({nav.popBackStack()},Modifier.fillMaxWidth()){Text("Cancelar")}
    }
}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){
    OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(label)})
}
