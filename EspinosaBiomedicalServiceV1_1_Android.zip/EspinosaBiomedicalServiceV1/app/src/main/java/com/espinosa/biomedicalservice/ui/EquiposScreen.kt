package com.espinosa.biomedicalservice.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.espinosa.biomedicalservice.data.EquipoDao
import com.espinosa.biomedicalservice.data.ClienteDao
import kotlinx.coroutines.launch

@Composable fun EquiposScreen(dao:EquipoDao,clienteDao:ClienteDao,nav:NavController){
    val equipos by dao.observarActivos().collectAsState(emptyList())
    val clientes by clienteDao.observarActivos().collectAsState(emptyList())
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            Text("Equipos",style=MaterialTheme.typography.headlineSmall)
            Button({nav.navigate("nuevo_equipo")}){Text("＋")}
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(equipos){e->val c=clientes.firstOrNull{it.id==e.clienteId}
                Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
                    Text("${e.marca} ${e.modelo}".trim(),style=MaterialTheme.typography.titleMedium)
                    Text("Tipo: ${e.tipo}"); Text("Serie: ${e.numeroSerie.ifBlank{"Sin registrar"}}")
                    Text("Cliente: ${c?.nombre ?: "No encontrado"}"); Text("Estado: ${e.estado}")
                    OutlinedButton({scope.launch{dao.archivar(e.id)}}){Text("🗑️ Archivar")}
                }}
            }
        }
    }
}
