package com.espinosa.biomedicalservice.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.espinosa.biomedicalservice.data.*
import kotlinx.coroutines.launch

@Composable fun EquipoFormScreen(dao:EquipoDao,clienteDao:ClienteDao,nav:NavController){
    val clientes by clienteDao.observarActivos().collectAsState(emptyList())
    val scope=rememberCoroutineScope()
    var clienteId by remember{mutableStateOf<Long?>(null)}
    var tipo by remember{mutableStateOf("")}; var marca by remember{mutableStateOf("")}
    var modelo by remember{mutableStateOf("")}; var serie by remember{mutableStateOf("")}
    var inventario by remember{mutableStateOf("")}; var estado by remember{mutableStateOf("Operativo")}
    var ubicacion by remember{mutableStateOf("")}; var observaciones by remember{mutableStateOf("")}
    LaunchedEffect(clientes){if(clienteId==null)clienteId=clientes.firstOrNull()?.id}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Nuevo equipo",style=MaterialTheme.typography.headlineSmall)
        if(clientes.isEmpty()) Text("Primero crea un cliente.") else LazyColumn(Modifier.heightIn(max=180.dp)){
            items(clientes){c->FilterChip(selected=clienteId==c.id,onClick={clienteId=c.id},label={Text(c.nombre)})}
        }
        Field("Tipo de equipo",tipo){tipo=it}; Field("Marca",marca){marca=it}; Field("Modelo",modelo){modelo=it}
        Field("Número de serie",serie){serie=it}; Field("Número de inventario",inventario){inventario=it}
        Field("Ubicación",ubicacion){ubicacion=it}; Field("Estado",estado){estado=it}; Field("Observaciones",observaciones){observaciones=it}
        Button(enabled=clienteId!=null&&tipo.isNotBlank(),onClick={scope.launch{
            dao.insertar(Equipo(clienteId=clienteId!!,tipo=tipo,marca=marca,modelo=modelo,numeroSerie=serie,numeroInventario=inventario,ubicacion=ubicacion,estado=estado,observaciones=observaciones))
            nav.popBackStack()
        }},Modifier.fillMaxWidth()){Text("Guardar equipo")}
        OutlinedButton({nav.popBackStack()},Modifier.fillMaxWidth()){Text("Cancelar")}
    }
}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(label)})}
