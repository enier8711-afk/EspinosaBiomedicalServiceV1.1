package com.espinosa.biomedicalservice.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable fun InicioScreen(nav:NavController){
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        Text("ESPINOSA BIOMEDICAL SERVICE",style=MaterialTheme.typography.headlineSmall)
        Text("Mantenimiento la tecnología que cuida la vida")
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
            Button({nav.navigate("nuevo_cliente")}){Text("＋ Cliente")}
            OutlinedButton({nav.navigate("nuevo_equipo")}){Text("＋ Equipo")}
        }
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
            Text("V1 — Gestión básica",style=MaterialTheme.typography.titleMedium)
            Text("👥 Clientes"); Text("🏥 Equipos"); Text("🗑️ Archivado y papelera")
            Text("Siguientes: 🔧 Servicios • 📄 Informes • 💰 Presupuestos")
        }}
    }
}
