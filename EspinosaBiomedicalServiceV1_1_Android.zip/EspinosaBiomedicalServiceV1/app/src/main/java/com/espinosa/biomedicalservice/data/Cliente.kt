package com.espinosa.biomedicalservice.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clientes")
data class Cliente(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val rut: String = "",
    val contacto: String = "",
    val cargo: String = "",
    val telefono: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val direccion: String = "",
    val ciudad: String = "",
    val departamento: String = "",
    val observaciones: String = "",
    val archivado: Boolean = false,
    val fechaRegistro: Long = System.currentTimeMillis()
)
