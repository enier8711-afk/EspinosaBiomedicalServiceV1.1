package com.espinosa.biomedicalservice.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EquipoDao {
    @Query("SELECT * FROM equipos WHERE archivado=0 ORDER BY marca, modelo")
    fun observarActivos(): Flow<List<Equipo>>
    @Query("SELECT * FROM equipos WHERE clienteId=:clienteId AND archivado=0 ORDER BY marca, modelo")
    fun observarPorCliente(clienteId: Long): Flow<List<Equipo>>
    @Insert suspend fun insertar(equipo: Equipo): Long
    @Update suspend fun actualizar(equipo: Equipo)
    @Query("UPDATE equipos SET archivado=1 WHERE id=:id") suspend fun archivar(id: Long)
    @Query("UPDATE equipos SET archivado=0 WHERE id=:id") suspend fun restaurar(id: Long)
    @Query("DELETE FROM equipos WHERE id=:id") suspend fun eliminarDefinitivamente(id: Long)
    @Query("SELECT * FROM equipos WHERE archivado=1 ORDER BY marca, modelo") fun observarPapelera(): Flow<List<Equipo>>
}
