package com.espinosa.biomedicalservice.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.espinosa.biomedicalservice.data.AppDatabase

@Composable
fun App() {
    val nav = rememberNavController()
    val db = AppDatabase.get(LocalContext.current)
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentRoute == "inicio",
                    onClick = { nav.navigate("inicio") { launchSingleTop = true; popUpTo("inicio") { saveState = true } } },
                    icon = { Text("⌂") },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = currentRoute == "clientes",
                    onClick = { nav.navigate("clientes") { launchSingleTop = true } },
                    icon = { Text("👥") },
                    label = { Text("Clientes") }
                )
                NavigationBarItem(
                    selected = currentRoute == "equipos",
                    onClick = { nav.navigate("equipos") { launchSingleTop = true } },
                    icon = { Text("⚙") },
                    label = { Text("Equipos") }
                )
            }
        }
    ) { pad ->
        NavHost(navController = nav, startDestination = "inicio", modifier = Modifier.padding(pad)) {
            composable("inicio") { InicioScreen(nav) }
            composable("clientes") { ClientesScreen(db.clienteDao(), nav) }
            composable("nuevo_cliente") { ClienteFormScreen(db.clienteDao(), nav) }
            composable("equipos") { EquiposScreen(db.equipoDao(), db.clienteDao(), nav) }
            composable("nuevo_equipo") { EquipoFormScreen(db.equipoDao(), db.clienteDao(), nav) }
        }
    }
}
