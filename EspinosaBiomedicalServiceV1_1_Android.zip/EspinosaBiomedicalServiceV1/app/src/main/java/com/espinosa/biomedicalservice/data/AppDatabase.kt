package com.espinosa.biomedicalservice.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities=[Cliente::class, Equipo::class], version=1, exportSchema=false)
abstract class AppDatabase: RoomDatabase() {
    abstract fun clienteDao(): ClienteDao
    abstract fun equipoDao(): EquipoDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "espinosa_biomedical.db").build().also { INSTANCE=it }
        }
    }
}
