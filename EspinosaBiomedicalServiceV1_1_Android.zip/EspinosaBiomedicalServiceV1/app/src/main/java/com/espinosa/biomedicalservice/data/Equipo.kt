package com.espinosa.biomedicalservice.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "equipos")
data class Equipo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clienteId: Long,
    val tipo: String,
    val marca: String = "",
    val modelo: String = "",
    val numeroSerie: String = "",
    val numeroInventario: String = "",
    val fabricante: String = "",
    val anioFabricacion: String = "",
    val ubicacion: String = "",
    val estado: String = "Operativo",
    val ultimoMantenimiento: Long? = null,
    val proximoMantenimiento: Long? = null,
    val frecuenciaMantenimientoMeses: Int? = null,
    val observaciones: String = "",
    val archivado: Boolean = false,
    val fechaRegistro: Long = System.currentTimeMillis()
)
