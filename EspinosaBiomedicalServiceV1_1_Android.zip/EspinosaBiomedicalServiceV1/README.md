# Espinosa Biomedical Service V1.1

Proyecto Android base para **Espinosa Biomedical Service**, preparado para abrirse y compilarse con Android Studio.

## Incluye
- Inicio de la aplicación.
- Alta de clientes.
- Alta de equipos asociados a clientes.
- Persistencia local con Room.
- Archivado lógico de clientes y equipos.
- Navegación inferior corregida con Jetpack Compose Material 3.
- `versionCode = 11` y `versionName = 1.1`.
- Compatible desde Android 8.0 (API 26) y preparado para Android 15 (API 35).

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK 35.
- Conexión a Internet la primera vez que Gradle descargue dependencias.

## Compilar la APK
1. Descomprime este ZIP.
2. Abre la carpeta `EspinosaBiomedicalServiceV1` en Android Studio.
3. Espera la sincronización de Gradle.
4. Selecciona **Build > Build APK(s)**.
5. La APK de depuración quedará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`

## Nota
Esta V1.1 corrige la navegación y deja el proyecto preparado para la siguiente etapa. Todavía no incluye servicios, fotografías, informes PDF, presupuestos, facturas, pagos, agenda ni sincronización en la nube.
